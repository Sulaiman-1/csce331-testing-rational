package numbers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThrows;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class RationalTest extends TestCase 
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public RationalTest(String testName) 
    {
        super(testName);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite() 
    {
        return new TestSuite(RationalTest.class);
    }

    /**
     * Rigourous Test :-)
    */
    
    //#region constructor tests
    public void test_DefaultConstructor() 
    {
        Rational r = new Rational();
        assertThat("Default constructor sets numerator to 0", r.numerator(), is(0));
        assertThat("Default constructor sets denominator to 1", r.denominator(), is(1));
    }

    public void test_OneArgConstructor_DefaultDenominator() 
    {
        Rational r = new Rational(1);
        assertThat("Numerator is correctly set to 1 with default constructor", r.numerator(), is(1));
        assertThat("Denominator defaults to 1 with one-argument constructor", r.denominator(), is(1));
    }
    
    public void test_OneArgConstructor_NegativeNumerator() 
    {
        Rational value = new Rational(-1);
        assertThat("Numerator is correctly set to -1 for negative input", value.numerator(), is(-1));
        assertThat("Denominator remains 1 for negative numerator input", value.denominator(), is(1));
    }

    public void test_TwoArgConstructor_PositiveValues() 
    {
        Rational r = new Rational(1, 2);
        assertThat("Numerator set to 1 as specified", r.numerator(), is(1));
        assertThat("Denominator set to 2 as specified", r.denominator(), is(2));

        assertThrows(IllegalArgumentException.class, () -> new Rational(Integer.MAX_VALUE, Integer.MIN_VALUE));
    }
    
    public void test_TwoArgConstructor_PositiveNumeratorNegativeDenominator() 
    {
        Rational value = new Rational(-2, 3);
        assertThat("Correctly handles negative numerator (-2)", value.numerator(), is(-2));
        assertThat("Denominator correctly remains positive (3)", value.denominator(), is(3));
        assertThrows(IllegalArgumentException.class, () -> new Rational(Integer.MAX_VALUE, Integer.MIN_VALUE));
    }
    
    public void test_TwoArgConstructor_NegativeNumeratorPositiveDenominator() 
    {
        Rational value = new Rational(2, -3);
        assertThat("Numerator adjusted to -2 when denominator is negative", value.numerator(), is(-2));
        assertThat("Denominator adjusted to positive (3) despite being input as negative", value.denominator(), is(3));
        assertThrows(IllegalArgumentException.class, () -> new Rational(Integer.MAX_VALUE, Integer.MIN_VALUE));
    }
    
    public void test_TwoArgConstructor_NegativeValues() 
    {
        Rational value = new Rational(-2, -3);
        assertThat("Numerator becomes positive (2) when both inputs are negative", value.numerator(), is(2));
        assertThat("Denominator becomes positive (3) when both inputs are negative", value.denominator(), is(3));
        assertThrows(IllegalArgumentException.class, () -> new Rational(Integer.MAX_VALUE, Integer.MIN_VALUE));
    }
    
    public void test_CanonicalForm_NegativeDenominator() 
    {
        Rational value = new Rational(48, -72);
        assertThat("Numerator correctly adjusted to -2 after simplification with a negative denominator", value.numerator(), is(-2));
        assertThat("Denominator adjusted to 3, confirming simplification works with negative denominators", value.denominator(), is(3));
        assertThrows(IllegalArgumentException.class, () -> new Rational(1, 0));
    }
    
    public void test_Reduction_WhenNumeratorIsGreaterThanDenominator() 
    {
        Rational value = new Rational(6, 3);
        assertThat("Rational 6/3 simplifies to 2/1, indicating correct reduction", value.numerator(), is(2));
        assertThat("Rational 6/3 simplifies to 2/1, maintaining correct ratio", value.denominator(), is(1));
    }
    
    public void test_CopyConstructor_ReplicatesOriginalRational() 
    {
        Rational original = new Rational(2, 3);
        Rational copy = new Rational(original);
    
        assertThat("Numerator of copy matches original", copy.numerator(), is(2));
        assertThat("Denominator of copy matches original", copy.denominator(), is(3));
    }
    
    public void test_CopyConstructor_NegativeNumeratorMaintained() 
    {
        Rational original = new Rational(-9, 8000);
        Rational copy = new Rational(original);
        assertThat("Copy maintains original's negative numerator", copy.numerator(), is(-9));
        assertThat("Copy's denominator is identical to original's", copy.denominator(), is(8000));
    }
    
    public void test_CopyConstructor_SimplifiedRationalMaintainsReduction() 
    {
        Rational original = new Rational(-1000, 8000);
        Rational copy = new Rational(original);
        assertThat("Copy correctly simplifies numerator from original's ratio", copy.numerator(), is(-1));
        assertThat("Copy correctly simplifies denominator from original's ratio", copy.denominator(), is(8));
    }
    
    public void test_Reduction_WhenNumeratorIsLessThanDenominator() 
    {
        Rational value = new Rational(2, 6);
        assertThat("Reduces to simplified numerator for 2/6", value.numerator(), is(1));
        assertThat("Reduces to simplified denominator for 2/6", value.denominator(), is(3));
    }
    
    public void test_Simplification_WhenNumeratorEqualsDenominator() 
    {
        Rational value = new Rational(3, 3);
        assertThat("Simplifies to 1 when numerator equals denominator", value.numerator(), is(1));
        assertThat("Simplifies denominator to 1 when numerator equals denominator", value.denominator(), is(1));
    }

    public void test_CopyConstructor_ValuesMatchOriginal() 
    {
        Rational original = new Rational(2, 3);
        Rational copy = new Rational(original);
        assertThat("Copy constructor should replicate original's numerator exactly", copy.numerator(), is(2));
        assertThat("Copy constructor should replicate original's denominator exactly", copy.denominator(), is(3));
    }
    
    public void test_TwoArgConstructor_ZeroNumeratorNormalized() 
    {
        Rational value = new Rational(0, -72);
        assertThat("Numerator of 0 remains unchanged after normalization", value.numerator(), is(0));
        assertThat("Denominator is normalized to 1 when numerator is 0", value.denominator(), is(1));
    }
    
    public void test_TwoArgConstructor_DenominatorZeroThrowsException() 
    {
        assertThrows(IllegalArgumentException.class, () -> new Rational(1, 0));
    }
    
    public void test_TwoArgConstructor_NegativeValuesNormalized() 
    {
        Rational value = new Rational(-63, -18);
        assertThat("Negative values are normalized, numerator becomes positive", value.numerator(), is(7));
        assertThat("Negative values are normalized, denominator becomes positive", value.denominator(), is(2));
    }

    
    public void test_TwoArgConstructor_MinValueWithNegativeDenominator_ThrowsException() 
    {
        assertThrows(IllegalArgumentException.class, () -> new Rational(Integer.MIN_VALUE, -1));
    }
    
    public void test_TwoArgConstructor_PositiveNumeratorWithMinValueDenominator_ThrowsException() 
    {
        assertThrows(IllegalArgumentException.class, () -> new Rational(1, Integer.MIN_VALUE));
    }
    
    public void test_TwoArgConstructor_ZeroNumeratorWithMinValueDenominator_Normalizes() 
    {
        Rational value = new Rational(0, Integer.MIN_VALUE);
        assertThat("Normalization ensures numerator remains 0 when denominator is Integer.MIN_VALUE", value.numerator(), is(0));
        assertThat("Normalization changes denominator to 1 from Integer.MIN_VALUE with a zero numerator", value.denominator(), is(1));
    }
    
    // public void test_TwoArgConstructor_MinValueNumeratorAndDenominator_ThrowsException() 
    // {
    //     assertThrows(IllegalArgumentException.class, () -> new Rational(Integer.MIN_VALUE, Integer.MIN_VALUE));

    // }
    

    //#endregion
    
    //#region utilities tests
    public void test_RationalAddInverse() 
    {
        Rational value = new Rational(2, 3);
        Rational opposite = value.opposite();
        assertThat("Opposite should negate the numerator to -2, keeping the denominator unchanged", opposite.numerator(), is(-2));
        assertThat("Denominator remains as 3 when finding the opposite", opposite.denominator(), is(3));

        value = new Rational(-2, 5);
        opposite = value.opposite();
        assertThat("Numerator is negated back to positive 2 for the opposite of -2/5", opposite.numerator(), is(2));
        assertThat("Denominator stays at 5 for the opposite", opposite.denominator(), is(5));

        value = new Rational(2, -5);
        opposite = value.opposite();
        assertThat("Opposite operation keeps numerator positive when denominator is negative", opposite.numerator(), is(2));
        assertThat("Opposite operation normalizes the negative denominator to positive", opposite.denominator(), is(5));
    }

    public void test_AddInverseIntegerMin() 
    {
        Rational value = new Rational(Integer.MIN_VALUE, 1);
        assertThrows(IllegalArgumentException.class, value::opposite);
    }

    public void test_Reciprocal_NonZeroNumerator() 
    {
        Rational value = new Rational(2, 3);
        Rational reciprocal = value.reciprocal();
        assertThat("Reciprocal inverts the original ratio, making numerator 3", reciprocal.numerator(), is(3));
        assertThat("Reciprocal inverts the original ratio, making denominator 2", reciprocal.denominator(), is(2));
    }

    public void test_Reciprocal_ZeroNumerator() 
    {
        Rational value = new Rational(0);
        assertThrows(IllegalArgumentException.class, value::reciprocal);
    }

    public void test_ReciprocalWithMinValueNumerator_ThrowsException() 
    {
        Rational value = new Rational(Integer.MIN_VALUE, 1);
        assertThrows(IllegalArgumentException.class, value::reciprocal);
    }

    public void test_ReciprocalOfMaxValueNumerator_MinValuePlusOneDenominator() 
    {
        Rational value = new Rational(Integer.MAX_VALUE, Integer.MIN_VALUE + 1);
        Rational reciprocal = value.reciprocal();

        assertThat("Reciprocal swaps MAX_VALUE numerator with MIN_VALUE+1 denominator to -1", reciprocal.numerator(), is(-1));
        assertThat("Reciprocal confirms denominator is normalized to 1", reciprocal.denominator(), is(1));
    }

    public void test_ReciprocalOfMaxValueNumerator_MinValuePlusTwoDenominator() 
    {
        Rational value = new Rational(Integer.MAX_VALUE, Integer.MIN_VALUE + 2);
        Rational reciprocal = value.reciprocal();

        assertThat("Reciprocal adjusts numerator for reciprocal operation with large values", reciprocal.numerator(), is(-(Integer.MAX_VALUE - 1)));
        assertThat("Reciprocal matches expected large denominator for MAX_VALUE numerator", reciprocal.denominator(), is(Integer.MAX_VALUE));
    }

//#endregion

    //#region addition
    public void test_Plus_SimpleFractionAddition() 
    {
        Rational a = new Rational(1, 10);
        Rational b = new Rational(9, 10);
        Rational sum = a.plus(b);
        assertThat("1/10 + 9/10 = 1/1", sum.numerator(), is(1));
        assertThat("1/10 + 9/10 = 1/1", sum.denominator(), is(1));

        Rational a1 = new Rational(-1, 10);
        Rational b1 = new Rational(-9, 10);
        Rational sum1 = a1.plus(b1);
        assertThat("1/10 + 9/10 = -1/1", sum1.numerator(), is(-1));
        assertThat("1/10 + 9/10 = -1/1", sum1.denominator(), is(1));

        Rational c = new Rational(1, Integer.MAX_VALUE - 2);
        Rational d = new Rational(1, Integer.MAX_VALUE / 2);
        assertThrows(IllegalArgumentException.class, () -> c.plus(d));

        Rational e = new Rational(Integer.MAX_VALUE, 1);
        Rational f = new Rational(Integer.MAX_VALUE, 1);
        assertThrows(IllegalArgumentException.class, () -> e.plus(f));
    }

    public void test_Plus_NegativeNumeratorsAndDenominators() 
    {
        Rational l = new Rational(-1920, 1080);
        Rational r = new Rational(4097, -3312);
        Rational result = l.plus(r);
        assertThat("-1920/1080 + 4097 = -9985/3312", result.numerator(), is(-9985));
        assertThat("-1920/1080 + 4097 = -9985/3312", result.denominator(), is(3312));
    }

    public void test_Plus_MaxIntEdgeCase() 
    {
        Rational l = new Rational(Integer.MAX_VALUE, 1);
        Rational r = new Rational(1, 1);
        assertThrows(IllegalArgumentException.class, () -> l.plus(r));
    }

    public void test_Plus_MinIntEdgeCase() 
    {
        Rational l = new Rational(1, Integer.MAX_VALUE);
        Rational r = new Rational(1, Integer.MAX_VALUE);
        Rational result = l.plus(r);

        assertThat("1/2^30 + 1/2^30 = 1/2^29", result.numerator(), is(2));
        assertThat("1/2^30 + 1/2^30 = 1/2^29", result.denominator(), is(Integer.MAX_VALUE));
    }

    public void test_Plus_LargeDenominatorAddition() 
    {
        Rational l = new Rational(Integer.MIN_VALUE, 1);
        Rational r = new Rational(Integer.MIN_VALUE, 1);
        assertThrows(IllegalArgumentException.class, () -> l.plus(r));
    }

    public void test_Plus_IntegerOverflowPrevention() 
    {
        Rational l = new Rational(2147483645, 1);
        Rational r = new Rational(2, 1);
        Rational result = l.plus(r);
        assertThat("2147483645/1 + 2/1 = INTMAX/1", result.numerator(), is(Integer.MAX_VALUE));
        assertThat("147483645/1 + 2/1 = INTMAX/1", result.denominator(), is(1));
    }

    public void test_Plus_MixedSignsResultingInSimplification() 
    {
        Rational l = new Rational(Integer.MAX_VALUE - 100, Integer.MAX_VALUE - 4003);
        Rational r = new Rational(Integer.MAX_VALUE - 50, Integer.MAX_VALUE - 4000);
        assertThrows(IllegalArgumentException.class, () -> l.plus(r));
    }

    public void test_Plus_AdditionResultingInNormalization() 
    {
        Rational l = new Rational(Integer.MIN_VALUE + 5, 3);
        Rational r = new Rational(2, 4);
        Rational result = l.plus(r);
        assertThat("operation", result.numerator(), is(-1431655761));
        assertThat("operation", result.denominator(), is(2));
    }

    public void test_Plus_ExtremeValueAdditionHandling() 
    {
        Rational l = new Rational(Integer.MIN_VALUE + 10, 4);
        Rational r = new Rational(Integer.MIN_VALUE + 5, 3);
        assertThrows(IllegalArgumentException.class, () -> l.plus(r));
    }

    public void test_Plus_AdditionWithPowerOfTwoDenominators() 
    {
        Rational l = new Rational(1, (int) Math.pow(2, 20));
        Rational r = new Rational(1, ((int) Math.pow(2, 20)) + 1);
        assertThrows(IllegalArgumentException.class, () -> l.plus(r));
    }
    //#endregion

    //#region subtraction
    public void test_Minus_BasicSubtraction() 
    {
        Rational a = new Rational(1, 2);
        Rational b = new Rational(19, 10);
        Rational difference = a.minus(b);

        assertThat("1/2 + 19/10 = -7/5", difference.numerator(), is(-7));
        assertThat("1/2 + 19/10 = -7/5", difference.denominator(), is(5));
    }

    public void test_Minus_WithPositiveOperands() 
    {
        Rational a = new Rational(1, 2);
        Rational b = new Rational(19, 10);
        Rational difference = a.minus(b);

        assertEquals("1/2 - 19/10 = -7/5", -7, difference.numerator());
        assertEquals("1/2 - 19/10 = -7/5", 5, difference.denominator());
    }

    public void test_Minus_WithBothNegativeOperands() 
    {
        Rational a = new Rational(-1, 2);
        Rational b = new Rational(-19, 10);
        Rational difference = a.minus(b);

        assertEquals("-1/2 - (-19/10) = 7/5", 7, difference.numerator());
        assertEquals("-1/2 - (-19/10) = 7/5", 5, difference.denominator());
    }

    public void test_Minus_WithFirstOperandNegative() 
    {
        Rational a = new Rational(-1, 2);
        Rational b = new Rational(19, 10);
        Rational difference = a.minus(b);

        assertEquals("-1/2 - 19/10 = -12/5", -12, difference.numerator());
        assertEquals("-1/2 - 19/10 = -12/5", 5, difference.denominator());
    }

    public void test_Minus_WithSecondOperandNegative() 
    {
        Rational a = new Rational(1, 5);
        Rational b = new Rational(-9, 10);
        Rational diff = a.minus(b);
        assertEquals("1/5 - (-9/10) = 11/10", 11, diff.numerator());
        assertEquals("1/5 - (-9/10) = 11/10", 10, diff.denominator());
    }

    public void test_Minus_ToCheckOverflow() 
    {
        Rational a = new Rational(Integer.MAX_VALUE);
        Rational b = new Rational(-1);

        assertThrows(IllegalArgumentException.class, () -> a.minus(b));
    }

    public void test_Minus_ToCheckUnderflow() 
    {
        Rational a = new Rational(Integer.MIN_VALUE);
        Rational b = new Rational(1);

        assertThrows(IllegalArgumentException.class, () -> a.minus(b));
    }
    
    public void test_Minus_SameDenominator()
    {
        Rational r = new Rational(1, 2);
        Rational r2 = new Rational(3, 2);

        assertThat("1/2 - 3/2 = -1", r.minus(r2).numerator(), is(-1));
    }
    
    //#endregion

    //#region multiplication
    public void test_times() 
    {
        Rational p = new Rational(2, 3);
        Rational q = new Rational(5, 7);
        Rational result = p.times(q);
        assertThat("2 * 5 = 10", result.numerator(), is(10));
        assertThat("3 * 7 = 21", result.denominator(), is(21));
    }

    public void test_times_NegativeOperands() 
    {
        Rational a = new Rational(-1, 5);
        Rational b = new Rational(-9, 10);
        Rational product = a.times(b);
        assertEquals("-1/5 * -9/10 = 9/50", 9, product.numerator());
        assertEquals("-1/5 * -9/10 = 9/50", 50, product.denominator());
    }

    public void test_times_OneNegativeOperand() 
    {
        Rational a = new Rational(1, 5);
        Rational b = new Rational(-9, 10);
        Rational product = a.times(b);
        assertEquals("1/5 * -9/10 = -9/50", -9, product.numerator());
        assertEquals("1/5 * -9/10 = -9/50", 50, product.denominator());
    }

    public void test_times_Overflow() 
    {
        Rational a = new Rational(Integer.MAX_VALUE, 1);
        Rational b = new Rational(2, 1);
        assertThrows(IllegalArgumentException.class, () -> a.times(b));
    }

    public void test_times_Underflow() 
    {
        Rational a = new Rational(Integer.MIN_VALUE, 1);
        Rational b = new Rational(2, 1);
        assertThrows(IllegalArgumentException.class, () -> a.times(b));
    }
    //#endregion

    //#region division
    public void test_dividedBy() 
    {
        Rational p = new Rational(2, 3);
        Rational q = new Rational(5, 7);
        Rational quotient = p.dividedBy(q);
        assertThat("2 * 5 = 10", quotient.numerator(), is(14));
        assertThat("3 * 7 = 21", quotient.denominator(), is(15));
    }

    public void test_dividedBy_0() 
    {
        Rational p = new Rational(2, 3);
        Rational divide0 = new Rational(0);
        assertThrows(IllegalArgumentException.class, () -> p.dividedBy(divide0));
    }

    public void test_dividedBy_overflow() 
    {
        Rational a = new Rational(Integer.MIN_VALUE, Integer.MAX_VALUE);
        Rational b = new Rational(5, 2);
        assertThrows(IllegalArgumentException.class, () -> a.dividedBy(b));
    }
    //#endregion

    //#region raised to
    public void test_raisePowerneg() 
    {
        int power = -2;
        Rational a = new Rational(5, 2);
        Rational anegsquared = a.raisedToThePowerOf(power);
        assertThat("5/2 ^ -2 = 4 / 25", anegsquared.numerator(), is(4));
        assertThat("5/2 ^ -2 = 4 / 25", anegsquared.denominator(), is(25));
    }

    public void test_raisePower0andneg() 
    {
        int power = -2;
        Rational a = new Rational(0, 2);

        assertThrows(IllegalArgumentException.class, () -> a.raisedToThePowerOf(power));
    }

    public void test_raisePowerpos() 
    {
        int power = 2;
        Rational a = new Rational(5, 2);
        Rational asquared = a.raisedToThePowerOf(power);
        assertThat("5/2 ^2 = 25 /4 ", asquared.numerator(), is(25));
        assertThat("5/2 ^2 = 25 /4 ", asquared.denominator(), is(4));
    }

    public void test_RaisedToThePowerOfPositiveExponent() 
    {
        Rational rational = new Rational(2, 3);
        Rational result = rational.raisedToThePowerOf(3);
        assertEquals("2/3 raised to the power of 3 = 8/27", new Rational(8, 27), result);
    }

    public void test_RaisedToThePowerOfNegativeExponent() 
    {
        Rational rational = new Rational(2, 3);
        Rational result = rational.raisedToThePowerOf(-2);
        assertEquals("2/3 raised to the power of -2 = 9/4", new Rational(9, 4), result);
    }

    public void test_RaisedToThePowerOfOverflowNumerator() 
    {
        Rational rational = new Rational(Integer.MAX_VALUE, 1);
        assertThrows(IllegalArgumentException.class, () -> rational.raisedToThePowerOf(2));
    }

    public void test_RaisedToThePowerOfOverflowDenominator() 
    {
        Rational rational = new Rational(1, Integer.MAX_VALUE);
        assertThrows(IllegalArgumentException.class, () -> rational.raisedToThePowerOf(2));
    }

    public void test_RaisedToThePowerOfIntegerMinExponent() 
    {
        Rational rational = new Rational(2, 3);
        assertThrows(IllegalArgumentException.class, () -> rational.raisedToThePowerOf(Integer.MIN_VALUE));
    }

    public void test_raisedtopowerofintegerminoverflow() 
    {
        Rational rational = new Rational(Integer.MIN_VALUE, 1);
        int exponent = 3;
        assertThrows(IllegalArgumentException.class, () -> rational.raisedToThePowerOf(exponent));
    }

    public void test_raisedtopow1() 
    {
        Rational rational = new Rational(5, Integer.MIN_VALUE + 1);
        int exponent = 3;
        assertThrows(IllegalArgumentException.class, () -> rational.raisedToThePowerOf(exponent));
    }

    public void test_raisedtopow2() 
    {
        Rational rational = new Rational(0, 10);
        int exponent = 3;
        Rational result = rational.raisedToThePowerOf(exponent);
        assertEquals(result.numerator(), 0);
        assertEquals(result.denominator(), 1);
    }

    public void test_raisedtopow3() 
    {
        Rational rational = new Rational(5, Integer.MAX_VALUE / 2);
        int exponent = -2;
        assertThrows(IllegalArgumentException.class, () -> rational.raisedToThePowerOf(exponent));
    }

    public void test_raisedtopow4() 
    {
        Rational rational = new Rational(0, Integer.MAX_VALUE / 2);
        int exponent = 0;
        Rational result = rational.raisedToThePowerOf(exponent);
        assertEquals(result.numerator(), 1);
        assertEquals(result.denominator(), 1);
    }

    public void test_raisedtopow5() 
    {
        Rational rational = new Rational(1,1);
        int exponent = Integer.MAX_VALUE;
        Rational result = rational.raisedToThePowerOf(exponent);
        assertEquals(result.numerator(), 1);
        assertEquals(result.denominator(), 1);
    }
    //#endregion

    //#region equals
    public void test_Equals_IdenticalRationals() 
    {
        Rational a = new Rational(5, 2);
        Rational b = new Rational(5, 2);
        assertTrue(a.equals(b));
        assertTrue(a.equals(a));
    }

    public void test_Equals_DifferentNumerators() 
    {
        Rational a = new Rational(5, 2);
        Rational b = new Rational(9, 2);
        assertFalse(a.equals(b));
        assertTrue(a.equals(a));
    }

    public void test_Equals_DifferentDenominators() 
    {
        Rational a = new Rational(7, 3);
        Rational b = new Rational(7, 2);
        assertFalse(a.equals(b));
    }

    public void test_Equals_BothDiffer() 
    {
        Rational a = new Rational(5, 3);
        Rational b = new Rational(7, 2);
        assertFalse(a.equals(b));
    }

    public void test_Equals_NegativeNumerators() 
    {
        Rational a = new Rational(-5, 3);
        Rational b = new Rational(-7, 2);
        assertFalse(a.equals(b));
    }

    public void test_Equals_CompletelyIdenticalNegatives() 
    {
        Rational a = new Rational(-5, 3);
        Rational b = new Rational(-5, 3);
        assertTrue(a.equals(b));
    }

    public void test_Equals_ExtremeDenominators() 
    {
        Rational a = new Rational(7, Integer.MIN_VALUE + 1);
        Rational b = new Rational(-7, Integer.MAX_VALUE);
        assertTrue(a.equals(b));
    }

    public void test_Equals_DifferentObjectTypes() 
    {
        Rational a = new Rational(5, 2);
        String c = "hello";
        assertFalse((a.equals(c)));
    }

    public void test_Equals_WithFloat() 
    {
        Rational a = new Rational(5, 2);
        float b = 2.5f;
        float c = 3.3333f;
        assertTrue(a.equals(b));
        assertFalse(a.equals(c));
    }

    public void test_Equals_WithDoubleCloseValue() 
    {
        Rational a = new Rational(5, 2);
        double b = 2.499999999999999999999;
        double c = 3.3333;

        assertTrue(a.equals(b));
        assertFalse(a.equals(c));
    }
    
    public void test_equals_self()
    {
        Rational r = new Rational();
        boolean equals = r.equals(r);

        assertThat("r = r", equals, is(true));
    }

    public void test_equals_diffDenominator()
    {
        Rational r = new Rational(3, 5);
        Rational r2 = new Rational(3, 7);
        
        boolean equals = r.equals(r2);

        assertThat("denominators are not the same", equals, is(false));
    }
    
    public void test_equals_diffNumerator()
    {
        Rational r = new Rational(2, 5);
        Rational r2 = new Rational(3, 5);
        
        boolean equals = r.equals(r2);

        assertThat("numerators are not the same", equals, is(false));
    }
    
    public void test_equals_Number()
    {
        Number n = 0.5;
        Rational r = new Rational(1, 2);

        boolean equals = r.equals(n);

        assertThat("1/2 = 0.5", equals, is(true));
    }

    public void test_equals_Number_Sad()
    {
        Number n = 0.6;
        Rational r = new Rational(1, 2);

        boolean equals = r.equals(n);

        assertThat("1/2 = 0.6", equals, is(false));
    }

    public void test_equals_notNumber()
    {
        String a = "str";
        Rational r = new Rational();

        assertThat("char is not Rational or Number", r.equals(a), is(false));
    }
    
    public void test_Equals_Float_CloseEnough() 
    {
        Rational r = new Rational(1, 2);
        Float closeEnough = 0.5f + (float)Math.pow(2, -21);

        boolean result = r.equals(closeEnough);

        assertThat("Rational(1/2) should be considered 'equal' to Float closeEnough", result, is(true));
    }

    public void test_Equals_Float_NotCloseEnough() 
    {
        Rational r = new Rational(1, 2); // This is 0.5 when converted to double
        Float notCloseEnough = 0.5f + (float)Math.pow(2, -19); // Slightly more than 0.5 but outside 2^-20 difference

        boolean result = r.equals(notCloseEnough);

        assertThat("Rational(1/2) should not be considered 'equal' to Float notCloseEnough", result, is(false));
    }

    public void test_RationalEquals_Integer_WithDenominatorOne() 
    {
        Rational r = new Rational(5, 1); // Represents the integer 5
        Integer i = 5;
        assertThat(r.equals(i), is(true));
    }

    public void test_RationalNotEquals_Integer_WithDifferentValue() 
    {
        Rational r = new Rational(5);
        Integer i = 4;
        assertThat(r.equals(i), is(false));
    }

    public void test_RationalEquals_Long_WithDenominatorOne() //sad
    {
        Rational r = new Rational(3, 2);
        Long l = 5L;
        assertThat(r.equals(l), is(false));
    }

    public void test_RationalEquals_Byte_WithDenominatorOne() 
    {
        Rational r = new Rational(7, 2);
        Byte b = 5;
        assertThat(r.equals(b), is(false));
    }

    public void test_RationalEquals_Short_WithDenominatorOne() 
    {
        Rational r = new Rational(5);
        Short s = 5;
        assertThat(r.equals(s), is(true));
    }
    
    public void test_Equals_SpecialDoubleValues() 
    {
        Rational rational = new Rational(1, 2);
    
        assertFalse("Rational should not equal NaN", rational.equals(Double.NaN));
        assertFalse("Rational should not equal POSITIVE_INFINITY", rational.equals(Double.POSITIVE_INFINITY));
        assertFalse("Rational should not equal NEGATIVE_INFINITY", rational.equals(Double.NEGATIVE_INFINITY));
    }

    public void test_Equals_FloatingPointPrecision() 
    {
        Rational rational = new Rational(1, 3);
    
        double closeValue = 0.3333333333333333;
        assertTrue("Rational close to 0.3333 should be considered equal", rational.equals(closeValue));
    
        double outsideTolerance = 0.3334; 
        assertFalse("Rational should not be equal when outside tolerance", rational.equals(outsideTolerance));
    }

    public void test_Equals_WithNonNumberObjects() 
    {
        Rational rational = new Rational(5, 10);
    
        assertFalse("Rational should not be equal to null", rational.equals(null));
    
        String nonNumber = "Not a Number";
        assertFalse("Rational should not be equal to a non-number string", rational.equals(nonNumber));
    }
    
    public void test_Equals_RationalNormalization() 
    {
        Rational half = new Rational(1, 2);
        Rational normalizedHalf = new Rational(2, 4);
    
        assertTrue("Normalized Rational should be equal to half", half.equals(normalizedHalf));
    }
    
    public void test_Equals_AfterOperations() 
    {
        Rational r1 = new Rational(1, 3);
        Rational r2 = new Rational(1, 6);
        Rational sum = r1.plus(r2);
    
        Rational expected = new Rational(1, 2);
        assertTrue("Sum of 1/3 and 1/6 should equal 1/2", expected.equals(sum));
    }
    

    //#endregion

    //#region greater than
    public void test_greaterThan_Rational() 
    {
        Rational a = new Rational(3, 5);
        Rational b = new Rational(4, 10);
        assertTrue(a.greaterThan(b));
    }

    public void test_greaterThan_Rational_SAD() 
    {
        Rational a = new Rational(3, 5);
        Rational b = new Rational(4, 10);
        assertFalse(b.greaterThan(a));
    }
    
    //#endregion

    //#region less than
    public void test_lessThan_Rational() 
    {
        Rational a = new Rational(3, 5);
        Rational b = new Rational(4, 10);
        assertTrue(b.lessThan(a));
    }

    public void test_lessThan_Rational_SAD() 
    {
        Rational a = new Rational(3, 5);
        Rational b = new Rational(4, 10);
        assertFalse(a.lessThan(b));
    }
    

    //#endregion

    public void test_ComparisonWithFloat() 
    {
        Rational a = new Rational(6, 10);
        float b = 0.7f;
        float c = 0.5f;
        assertTrue(a.lessThan(b));
        assertTrue(a.greaterThan(c));

        assertFalse(a.lessThan(c));
        assertFalse(a.greaterThan(b));
    }

    public void test_ComparisonWithDouble() 
    {
        Rational a = new Rational(6, 10);
        double b = 0.7779;
        double c = 0.56789;
        assertTrue(a.lessThan(b));
        assertTrue(a.greaterThan(c));

        assertFalse(a.lessThan(c));
        assertFalse(a.greaterThan(b));
    }

    public void test_GreaterThan_WithRationalOperand() 
    {
        Rational a = new Rational(3, 5);
        Rational b = new Rational(1, 2);
        assertTrue(a.greaterThan(b));
    }

    public void test_LessThan_FloatPrecisionEdgeCase() 
    {
        Rational a = new Rational(1, 2);
        float b = 0.5f + (float) Math.pow(2, -20);
        assertTrue(a.lessThan(b));
    }

    public void test_Negatives_NormalizationAndComparison() 
    {
        Rational value = new Rational(-1, -5);
        assertThat("-1 / -5 = 1/5", value.numerator(), is(1));
        assertThat("-1 / -5 = 1/5", value.denominator(), is(5));

        value = new Rational(8, -5);
        assertThat("8/-5 = -8/5", value.numerator(), is(-8));
        assertThat("8/-5 = -8/5", value.denominator(), is(5));
    }

    public void test_GreaterThan_FloatPrecisionJustBelowHalf() 
    {
        Rational a = new Rational(1, 2);
        float b = 0.5f - (float) Math.pow(2, -20);
        assertTrue(a.greaterThan(b));
    }

    //#region valueChecks
    public void test_isZero() 
    {
        Rational a = new Rational(0, 5);
        assertTrue(a.isZero());

        Rational b = new Rational(5, 2);
        assertFalse(b.isZero());
    }

    public void test_isOne() 
    {
        Rational a = new Rational(7, 7);
        assertTrue(a.isOne());

        Rational b = new Rational(5, 2);
        assertFalse(b.isOne());
    }

    public void test_isMinusOne() 
    {
        Rational a = new Rational(7, -7);
        assertTrue(a.isMinusOne());

        Rational b = new Rational(5, 2);
        assertFalse(b.isMinusOne());
    }

    public void test_toString() 
    {
        Rational a = new Rational(7, -7);
        assertEquals("-1", a.toString());

        Rational b = new Rational(5, 2);
        assertEquals("5/2", b.toString());
    }
    //#endregion

    //#region test compareTo
    public void test_CompareToWithRationalEqual() 
    {
        Rational r1 = new Rational(2, 3);
        Rational r2 = new Rational(2, 3);
        assertEquals("Rational numbers should be equal", 0, r1.compareTo(r2));
    }

    public void test_CompareToWithRationalLessThan() 
    {
        Rational r1 = new Rational(1, 3);
        Rational r2 = new Rational(2, 3);
        assertEquals("r1 should be less than r2", -1, r1.compareTo(r2));
    }

    public void test_CompareToWithRationalGreaterThan() 
    {
        Rational r1 = new Rational(3, 2);
        Rational r2 = new Rational(2, 3);
        assertEquals("r1 should be greater than r2", 1, r1.compareTo(r2));
    }

    public void test_CompareToWithIntegerEqual() 
    {
        Rational r1 = new Rational(2, 1); // Equivalent to integer 2
        Integer i1 = 2;
        assertEquals("Rational number should be equal to integer", 0, r1.compareTo(i1));
    }

    public void test_CompareToWithIntegerLessThan() 
    {
        Rational r1 = new Rational(1, 2); // Equivalent to 0.5
        Integer i1 = 1;
        assertEquals("Rational number should be less than integer", -1, r1.compareTo(i1));
    }

    public void test_CompareToWithIntegerGreaterThan() 
    {
        Rational r1 = new Rational(3, 1); // Equivalent to integer 3
        Integer i1 = 2;
        assertEquals("Rational number should be greater than integer", 1, r1.compareTo(i1));
    }

    public void test_CompareToWithDoubleEqual() 
    {
        Rational r1 = new Rational(1, 2); // Equivalent to 0.5
        Double d1 = 0.5;
        assertEquals("Rational number should be equal to double", 0, r1.compareTo(d1));
    }

    public void test_CompareToWithDoubleLessThan() 
    {
        Rational r1 = new Rational(1, 4); // Equivalent to 0.25
        Double d1 = 0.5;
        assertEquals("Rational number should be less than double", -1, r1.compareTo(d1));
    }

    public void test_CompareToWithDoubleGreaterThan() 
    {
        Rational r1 = new Rational(3, 4); // Equivalent to 0.75
        Double d1 = 0.5;
        assertEquals("Rational number should be greater than double", 1, r1.compareTo(d1));
    }
    

public void compareTo_Integer() 
{
    Rational half = new Rational(1, 2);
    Integer one = 1;
    assertEquals(-1, half.compareTo(one));
}

public void compareTo_Long() 
{
    Rational two = new Rational(2, 1);
    Long threeLong = 3L;
    assertEquals(-1, two.compareTo(threeLong));
}

public void compareTo_Byte() 
{
    Rational two = new Rational(2, 1);
    Byte twoByte = 2;
    assertEquals(0, two.compareTo(twoByte));
}

public void compareTo_Short() 
{
    Rational three = new Rational(3, 1);
    Short twoShort = 2;
    assertEquals(1, three.compareTo(twoShort));
}

public void compareTo_Float() 
{
    Rational half = new Rational(1, 2);
    Float halfFloat = 0.5f;
    assertEquals(0, half.compareTo(halfFloat));
}

public void compareTo_Double() 
{
    Rational four = new Rational(4, 1);
    Double fiveDouble = 5.0;
    assertEquals(-1, four.compareTo(fiveDouble));
}

public void compareTo_AtomicInteger() 
{
    Rational one = new Rational(1, 1);
    AtomicInteger oneAtomic = new AtomicInteger(1);
    assertEquals(0, one.compareTo(oneAtomic));
}

public void compareTo_AtomicLong() 
{
    Rational ten = new Rational(10, 1);
    AtomicLong nineAtomic = new AtomicLong(9);
    assertEquals(1, ten.compareTo(nineAtomic));
}

public void compareTo_BigDecimal() 
{
    Rational quarter = new Rational(1, 4);
    BigDecimal quarterBig = new BigDecimal("0.25");
    assertEquals(0, quarter.compareTo(quarterBig));
}

public void compareTo_BigInteger() 
{
    Rational bigR = new Rational(Integer.MAX_VALUE, 1);
    BigInteger bigI = BigInteger.valueOf(Integer.MAX_VALUE);
    assertEquals(0, bigR.compareTo(bigI));
}

    //#endregion


    //#region test transitions
    public void test_longValue() 
    {
        Rational a = new Rational(4, 2);
        long b = 2;
        assertEquals(b, a.longValue());
    }

    public void test_intValue() 
    {
        Rational a = new Rational(4, 2);
        assertEquals(2, a.intValue());
    }

    public void test_floatValue()
    {
        Rational a = new Rational(1);
        float b = 1f;
        assertEquals(b, a.floatValue());
    }
    //#endregion

    public void testGreaterThanWithInteger() 
    {
        Rational half = new Rational(1, 2);
        Integer zero = 0;
        assert half.greaterThan(zero); // 1/2 should be greater than 0
    }
    
    public void testLessThanWithDouble() 
    {
        Rational half = new Rational(1, 2);
        Double onePointFive = 1.5;
        assert half.lessThan(onePointFive);
    }
    
    public void testGreaterThanWithAtomicLong() 
    {
        Rational bigR = new Rational(Integer.MAX_VALUE, 1);
        AtomicLong smallerLong = new AtomicLong(Integer.MAX_VALUE - 1);
        assert bigR.greaterThan(smallerLong);
    }
    
    public void testLessThanWithBigDecimal() 
    {
        Rational quarter = new Rational(1, 4);
        BigDecimal halfBig = new BigDecimal("0.5");
        assert quarter.lessThan(halfBig);
    }
    
    public void testGreaterThanWithRational() 
    {
        Rational threeQuarters = new Rational(3, 4);
        Rational half = new Rational(1, 2);
        assert threeQuarters.greaterThan(half);
    }
    
    public void testLessThanWithRational() 
    {
        Rational oneThird = new Rational(1, 3);
        Rational half = new Rational(1, 2);
        assert oneThird.lessThan(half); 
    }
    
}